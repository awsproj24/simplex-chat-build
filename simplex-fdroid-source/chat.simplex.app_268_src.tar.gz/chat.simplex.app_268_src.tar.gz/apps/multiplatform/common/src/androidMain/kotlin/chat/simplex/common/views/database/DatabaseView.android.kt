package chat.simplex.common.views.database

import chat.simplex.common.views.usersettings.restartApp

actual fun restartChatOrApp() {
  restartApp()
}
