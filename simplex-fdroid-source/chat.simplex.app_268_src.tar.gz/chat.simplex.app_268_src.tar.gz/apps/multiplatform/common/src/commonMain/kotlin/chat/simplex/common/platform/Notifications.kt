package chat.simplex.common.platform

expect fun allowedToShowNotification(): Boolean
