//
//  SimpleXChat.h
//  SimpleXChat
//
//  Created by Evgeny on 30/05/2022.
//  Copyright © 2022 SimpleX Chat. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SimpleXChat.
FOUNDATION_EXPORT double SimpleXChatVersionNumber;

//! Project version string for SimpleXChat.
FOUNDATION_EXPORT const unsigned char SimpleXChatVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SimpleXChat/PublicHeader.h>
